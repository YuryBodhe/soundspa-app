import { pgTable, serial, integer, text, boolean } from "drizzle-orm/pg-core";
import { tenants } from "../schema.pg";

export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id")
    .notNull()
    .references(() => tenants.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  // Тот самый Soul или системная роль
  systemPrompt: text("system_prompt").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});