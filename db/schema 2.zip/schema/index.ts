// db/index.ts

// 1. Твоя рабочая база (Стабильность)
export * from "./schema.pg"; 

// 2. Твои новые возможности (Развитие)
export * from "./schema/monitoring";
export * from "./schema/agents";