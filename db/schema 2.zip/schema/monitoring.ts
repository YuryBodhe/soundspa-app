import { pgTable, serial, integer, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { tenants } from "../schema.pg";

export const monitoringCurrent = pgTable("monitoring_current", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id")
    .notNull()
    .unique() 
    .references(() => tenants.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("offline"),
  lastPing: timestamp("last_ping", { withTimezone: true }).defaultNow(),
  // Метаданные: какой канал выбран, версия браузера, ошибки плеера
  metadata: jsonb("metadata").default({}).notNull(), 
});

export const monitoringLogs = pgTable("monitoring_logs", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id")
    .notNull()
    .references(() => tenants.id, { onDelete: "cascade" }),
  event: text("event").notNull(), // например: "channel_change", "stream_error"
  details: text("details"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});