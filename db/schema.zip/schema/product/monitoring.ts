import {
  pgTable,
  serial,
  integer,
  timestamp,
  text,
  jsonb,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

import { devices } from "./devices";

// ====================
// monitoring_current
// ====================
// Текущее состояние устройства (1 строка = 1 устройство)

export const monitoringCurrent = pgTable("monitoring_current", {
  deviceId: integer("device_id")
    .primaryKey()
    .references(() => devices.id, { onDelete: "cascade" }),

  // Последний heartbeat
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull(),

  // Когда устройство стало offline
  lastOfflineAt: timestamp("last_offline_at", { withTimezone: true }),

  // Когда снова стало online
  lastOnlineAt: timestamp("last_online_at", { withTimezone: true }),
});

// ====================
// monitoring_logs
// ====================
// История событий (логирование)

export const monitoringLogs = pgTable("monitoring_logs", {
  id: serial("id").primaryKey(),

  deviceId: integer("device_id")
    .notNull()
    .references(() => devices.id, { onDelete: "cascade" }),

  // Тип события (НЕ enum!)
  // heartbeat | offline | online | error | etc
  type: text("type").notNull(),

  // Дополнительные данные (например ошибка стрима)
  payload: jsonb("payload"),

  // Уровень (опционально, но полезно)
  level: text("level").default("info").notNull(), // info | warning | error

  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

// ====================
// relations
// ====================

export const monitoringCurrentRelations = relations(
  monitoringCurrent,
  ({ one }) => ({
    device: one(devices, {
      fields: [monitoringCurrent.deviceId],
      references: [devices.id],
    }),
  })
);

export const monitoringLogsRelations = relations(
  monitoringLogs,
  ({ one }) => ({
    device: one(devices, {
      fields: [monitoringLogs.deviceId],
      references: [devices.id],
    }),
  })
);