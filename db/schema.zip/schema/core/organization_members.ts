import { pgTable, serial, integer, uniqueIndex } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { users } from "./users";
import { organizations } from "./organizations";
import { userRoleEnum } from "../enums";
import { timestamps } from "../utils";

export const organizationMembers = pgTable(
  "organization_members",
  {
    id: serial("id").primaryKey(),
    
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
      
    organizationId: integer("organization_id")
      .notNull()
      .references(() => organizations.id, { onDelete: "cascade" }),
      
    role: userRoleEnum("role").notNull().default("manager"),
    
    ...timestamps,
  },
  (table) => ({
    // ТО САМОЕ ОГРАНИЧЕНИЕ: один юзер — одна роль в одной организации
    uniqueMembership: uniqueIndex("org_member_unique").on(table.userId, table.organizationId),
  })
);

export const organizationMembersRelations = relations(organizationMembers, ({ one }) => ({
  user: one(users, {
    fields: [organizationMembers.userId],
    references: [users.id],
  }),
  organization: one(organizations, {
    fields: [organizationMembers.organizationId],
    references: [organizations.id],
  }),
}));