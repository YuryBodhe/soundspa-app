import { pgTable, serial, text } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { timestamps } from "../utils";
import { organizationMembers } from "./organization_members";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(), // Теперь уникален на всю систему!
  password: text("password"),
  ...timestamps,
});

export const usersRelations = relations(users, ({ many }) => ({
  memberships: many(organizationMembers),
}));