import { pgTable, serial, integer, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Импорты из этой же папки (Core)
import { organizations } from "./organizations";

// Импорты из соседних папок (Product / Billing)
import { tenantChannels } from "../product/tenant_channels";
import { payments } from "../billing/payments";
import { devices } from "../product/devices"; // Импорт!

// Глобальные правила
import { tenantStatusEnum } from "../enums";
import { timestamps } from "../utils";


export const tenants = pgTable("tenants", 
  {
    id: serial("id").primaryKey(),
    // 1. Обязательная привязка к организации (NOT NULL)
    organizationId: integer("organization_id")
      .notNull()
      .references(() => organizations.id, { onDelete: "cascade" }),
    
    name: text("name").notNull(),
    // 2. Slug больше не глобально уникальный, уникальность проверим в индексе ниже
    slug: text("slug").notNull(), 
    brandName: text("brand_name"),
    
    // 3. Добавляем Timezone — критично для ИИ-расписаний
    timezone: text("timezone").default("UTC").notNull(),
    
    status: tenantStatusEnum("status").default("trial").notNull(),
    
    // Лимиты (пока оставляем active_slots, но помним про Quotas)
    activeSlots: integer("active_slots").default(1).notNull(),
    
    // Тайминги (денормализованные данные для быстрого чтения)
    trialStartedAt: timestamp("trial_started_at", { withTimezone: true, mode: "string" }),
    trialEndsAt: timestamp("trial_ends_at", { withTimezone: true, mode: "string" }),
    paidTill: timestamp("paid_till", { withTimezone: true, mode: "string" }),
    
    ...timestamps,
  },
  (table) => ({
    // 4. Композитный индекс: slug уникален только внутри одной организации
    orgSlugIdx: uniqueIndex("org_slug_idx").on(table.organizationId, table.slug),
  })
);

// В блоке tenantsRelations добавь many-связи:
export const tenantsRelations = relations(tenants, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [tenants.organizationId],
    references: [organizations.id],
  }),

  devices: many(devices),
  tenantChannels: many(tenantChannels),
  payments: many(payments),
}));